import React from 'react';

export default function Asset ({  image, description, askingprice }) {
    return (
        <div>
            <div>{image}</div>
            <div>{description}</div>
            <div>{askingprice}</div>
        </div>
    )
}