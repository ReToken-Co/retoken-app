import React, { useState } from 'react';
import axios from 'axios';

//import { useForm, Controller } from "react-hook-form";
import {
  Paper,
  FormControl,
  TextField,
  Typography,
  Grid,
} from "@material-ui/core";
import { Button } from "./globalStyles";
import { InputContainer, useStyles } from "./InputForm.style";

/*export default function InputForm(props) {
  const { control, handleSubmit } = useForm();*/

const API_URL = 'http://localhost:5000/properties/add';

export default function InputForm({ assets, setAssets }) {

  const classes = useStyles();

  const [ image, setImage ] = useState('');
  const [ description, setDescription ] = useState('');
  const [ askingPrice, setAskingPrice ] = useState('');

  function handleImage (e) {
    setImage(e.target.value)
  }

  function handleDescription (e) {
    setDescription(e.target.value)
  }

  function handleAskingPrice (e) {
    setAskingPrice(e.target.value)
  }

  async function handleCreate() {
    //dispatch({ type: 'CREATE_ASSET', image, description, askingPrice })
    const newAsset = { image, description, askingPrice }
    setAssets([ newAsset, ...assets ]);

    console.log("newAsset", newAsset)

    const headers = {
			"Content-type": "application/json"
			};
		const response = await axios.post(
			API_URL,
			newAsset,
			headers
		).catch(error => {
			console.log(error.response)
		});;

    console.log("response", response);
  }

  return (
    <div className={classes.root}>
      <InputContainer>
        <form onSubmit={e => { e.preventDefault (); handleCreate() }}>
          <Paper className={classes.paper}>
            <FormControl
              fullWidth
              className={classes.margin}
              variant="outlined"
            >
                  <TextField
                    id="owner"
                    label="Owner"
                    /*disabled*/
                    variant="outlined"
                  />
            </FormControl>
            <FormControl
              fullWidth
              className={classes.margin}
              variant="outlined"
            >
                  <TextField
                    id="addressStreet"
                    label="Street"
                    variant="outlined"
                  />
            </FormControl>
            <FormControl className={classes.margin} variant="outlined">
              <TextField id="city" label="City" variant="outlined" />
            </FormControl>
            <FormControl className={classes.margin} variant="outlined">
                  <TextField
                    id="state"
                    label="State/Province"
                    variant="outlined"
                  />
            </FormControl>
            <FormControl className={classes.margin} variant="outlined">
                  <TextField id="country" label="Country" variant="outlined" />
            </FormControl>
            <FormControl className={classes.margin} variant="outlined">
                  <TextField id="zipcode" label="Zipcode" variant="outlined" />
            </FormControl>
            <FormControl
              fullWidth
              className={classes.margin}
              variant="outlined"
            >
                  <TextField id="image" label="Image File" variant="outlined" value={image} onChange={handleImage} />
            </FormControl>
            <FormControl
              fullWidth
              className={classes.margin}
              variant="outlined"
            >
                  <TextField
                    id="description"
                    multiline
                    rows={4}
                    label="Description"
                    helperText=""
                    variant="outlined"
                    value={description}
                    onChange={handleDescription}
                  />
            </FormControl>
            <FormControl className={classes.margin} variant="outlined">
                  <TextField
                    id="askingprice"
                    label="Asking Price"
                    helperText="in (USD)"
                    variant="outlined"
                    value={askingPrice}
                    onChange={handleAskingPrice}
                  />
            </FormControl>
            <FormControl className={classes.margin} variant="outlined">
                  <TextField
                    id="duration"
                    label="Duration"
                    helperText="Duration (min)"
                    variant="outlined"
                  />
            </FormControl>
          </Paper>

          <Paper className={classes.paper}>
            <Grid container spacing={0}>
              <Grid item xs={12}>
                <Typography className={classes.margin} variant="h6">
                  Property Highlights
                </Typography>
              </Grid>
              <Grid item xs>
                <FormControl className={classes.margin} variant="outlined">
                      <TextField
                        id="propertyType"
                        label="Property Type"
                        variant="outlined"
                      />
                </FormControl>
              </Grid>
              <Grid item xs>
                <FormControl className={classes.margin} variant="outlined">
                      <TextField
                        id="builtSize"
                        label="Building Size"
                        variant="outlined"
                      />
                </FormControl>
              </Grid>
              <Grid item xs>
                <FormControl className={classes.margin} variant="outlined">
                      <TextField
                        id="landSize"
                        label="Land Size"
                        variant="outlined"
                      />  
                </FormControl>
              </Grid>
              <Grid item xs>
                <FormControl className={classes.margin} variant="outlined">
                      <TextField
                        id="yearBuilt"
                        label="Year Built"
                        variant="outlined"
                      />
                </FormControl>
              </Grid>
              <Grid item xs>
                <FormControl className={classes.margin} variant="outlined">
                      <TextField
                        id="occupancy"
                        label="Occupancy (%)"
                        variant="outlined"
                      />
                </FormControl>
              </Grid>
              <Grid item xs={12}></Grid>
            </Grid>
          </Paper>

          <Paper className={classes.paper}>
            <Grid container spacing={0}>
              <Grid item xs={12}>
                <Typography className={classes.margin} variant="h6">
                  Financials (USD)
                </Typography>
              </Grid>
              <Grid item xs>
                <FormControl className={classes.margin} variant="outlined">
                      <TextField
                        id="annualGrossRent"
                        label="Gross Rent/year"
                        helperText="rolling 12 months"
                        variant="outlined"
                      />
                </FormControl>
              </Grid>
              <Grid item xs>
                <FormControl className={classes.margin} variant="outlined">
                      <TextField
                        id="annualExpenses"
                        label="Annual Expenses"
                        variant="outlined"
                      />
                </FormControl>
              </Grid>
              <Grid item xs>
                <FormControl className={classes.margin} variant="outlined">
                      <TextField
                        id="NOI"
                        label="NOI"
                        variant="outlined"
                      />
                </FormControl>
              </Grid>
              <Grid item xs>
                <FormControl className={classes.margin} variant="outlined">
                      <TextField
                        id="expectedYield"
                        label="Expected Yield (%)"
                        variant="outlined"
                      />
                </FormControl>
              </Grid>
              <Grid item xs={12}></Grid>
            </Grid>
          </Paper>

          <Button
            className={classes.margin}
            fontBig
            id="submitButton"
            type="submit"
          >
            Add Asset
          </Button>
        </form>
      </InputContainer>
    </div>
  );
}
