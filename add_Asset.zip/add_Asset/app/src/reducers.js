function assetsReducer (state, action) {
    switch (action.type) {
        case 'CREATE_ASSET':
            const newAsset = { 
                image: action.image, 
                description: action.description, 
                askingprice: action.askingprice
            }
            return [ newAsset, ...state ]

            default: 
                return state;
    }
}

export default assetsReducer;