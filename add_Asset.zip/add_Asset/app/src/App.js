//import React, { useReducer } from 'react';
import React, { useState } from 'react';

//import Asset from './assets/Asset';
import InputForm from './InputForm';
import AssetList from './assets/AssetList';
//import assetsReducer from './reducers';


const defaultAssets = [
  {image:"Image 1", description:"Cosy Apartment in Central Downtown", askingprice:"1500000"},
  {image:"Image 2", description:"Charming Apartment in Central Downtown", askingprice:"2000000"}
]

function App() {
  //const [ assets, dispatchAssets ] = useReducer(assetsReducer, defaultAssets);
  const [ assets, setAssets ] = useState(defaultAssets);

  return (
    <div>
      <InputForm assets={assets} setAssets={setAssets} />
      <br />
      <hr />
      <AssetList assets={assets} />
    </div>
  );
}

export default App;
