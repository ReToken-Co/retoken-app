import React from 'react';

import Asset from './Asset';

export default function AssetList ({ assets = [] }) {
    return (
        <div>
            {assets.map((a, i) => (
                <React.Fragment key={'asset-' + i}>
                    <Asset {...a} />
                    <hr />
                </React.Fragment>
            ))}
        </div>
    )
}